# Automated Recon & Enumeration Framework

**Combine subdomain enumeration, port scanning, and service fingerprinting into one tool.**

This repository provides a ready-to-run framework for reconnaissance on Kali Linux.
It automates:
- Subdomain enumeration (Sublist3r or from-file)
- Deduplication and DNS resolution
- Fast HTTP/HTTPS probing
- Optional port scanning and service fingerprinting (nmap)
- Organized outputs under `outputs/<target>/`

> ⚠️ Use only on domains you own or have explicit permission to test.

## Features

- Fast "lite" mode: subdomain collection → dedupe → resolve → HTTP probes (designed for speed)
- Optional "full" mode: run nmap service/version detection and save outputs
- Concurrent processing using threads for speed
- Clean output structure for easy post-processing

## Quickstart (Kali Linux)

```bash
# 1) Download or clone this repo on your Kali box
git clone https://github.com/YOUR_USERNAME/automated-recon-enum.git
cd automated-recon-enum

# 2) Install prerequisites
sudo bash setup.sh

# 3) Clone Sublist3r (optional; required only for --use-sublist3r)
git clone https://github.com/aboul3la/Sublist3r.git

# 4) Run fast (lite) workflow using Sublist3r
python3 recon_all_in_one_lite.py --use-sublist3r example.com

# 5) Or use your own subdomain list
python3 recon_all_in_one_lite.py --from-file subs.txt example.com

# 6) Optional: run nmap fingerprinting on resolved hosts
./fingerprint_hosts.sh outputs/example.com/resolved.txt
```

## Output layout

```
outputs/<target>/
├── subdomains_raw.txt
├── subdomains_unique.txt
├── resolved.txt
└── fingerprints/
    └── <host>/
       ├── info.txt
       ├── http_headers.txt
       └── http_sample.html
```

## Files

- `recon_all_in_one_lite.py` — main lightweight Python tool (fast).
- `fingerprint_hosts.sh` — simple nmap wrapper for resolved hosts.
- `resolve_subdomains.sh` — bash helper to filter resolving hosts.
- `setup.sh` — install required packages on Kali.
- `examples/` — usage examples.

## Contributing
Feel free to open issues or PRs. If you want `amass`/`subfinder` integration or GitHub Actions for CI, open an issue and I can help.

## License
MIT — see `LICENSE`.
