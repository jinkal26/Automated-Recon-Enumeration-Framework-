#!/usr/bin/env bash
# Usage: ./fingerprint_hosts.sh resolved.txt
if [ $# -ne 1 ]; then
  echo "Usage: $0 resolved.txt"
  exit 1
fi
IN=$1
OUTDIR="fingerprints"
mkdir -p "$OUTDIR"
while read -r host; do
  [ -z "$host" ] && continue
  safe=$(echo "$host" | sed 's/[:/]/_/g')
  echo "[*] Running nmap -sV for $host"
  nmap -Pn -sV -p 21,22,25,53,80,110,143,443,587,8080,8443 "$host" -oA "$OUTDIR/$safe" || true
done < "$IN"
echo "[+] Done. See $OUTDIR/"
