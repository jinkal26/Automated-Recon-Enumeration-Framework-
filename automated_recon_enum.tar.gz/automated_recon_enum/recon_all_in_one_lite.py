#!/usr/bin/env python3
"""Automated Recon & Enumeration Framework - Lite

Fast workflow:
- Sublist3r (optional) to collect subdomains
- Dedupe
- Resolve A/AAAA
- HTTP/HTTPS probes (headers + body sample)
- Outputs stored in outputs/<target>/

Author: prepared for jinkal26
"""

import argparse
import shutil
import socket
import subprocess
import sys
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Optional

try:
    import requests
except Exception:
    requests = None

def check_command(cmd: str) -> bool:
    return shutil.which(cmd) is not None

def run_cmd(cmd, timeout=30):
    return subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, timeout=timeout)

def ensure_dir(p: Path):
    p.mkdir(parents=True, exist_ok=True)

def default_sublist3r_path():
    return str(Path.cwd() / "Sublist3r" / "sublist3r.py")

def run_sublist3r(domain: str, sublist3r_path: str, out_file: Path, timeout: int = 300):
    if not Path(sublist3r_path).exists():
        raise FileNotFoundError(f"Sublist3r not found at {sublist3r_path}")
    python3 = shutil.which("python3") or "python3"
    cmd = [python3, sublist3r_path, "-d", domain, "-o", str(out_file)]
    print("[*] Running Sublist3r:", " ".join(cmd))
    p = run_cmd(cmd, timeout=timeout)
    if p.returncode != 0:
        print("[!] Sublist3r returned non-zero. stderr:\n", p.stderr)

def dedupe_file(src: Path, dst: Path):
    lines = {ln.strip() for ln in src.read_text().splitlines() if ln.strip()}
    sorted_lines = sorted(lines)
    dst.write_text("\n".join(sorted_lines) + ("\n" if sorted_lines else ""))
    print(f"[+] Deduped {len(sorted_lines)} entries -> {dst}")

def resolve_host(host: str, timeout: float = 3.0) -> Optional[str]:
    try:
        ai = socket.getaddrinfo(host, None)
        if ai:
            return ai[0][4][0]
    except (socket.gaierror, OSError):
        pass
    if check_command("host"):
        try:
            p = run_cmd(["host", host], timeout=timeout)
            out = p.stdout.strip()
            for line in out.splitlines():
                if "has address" in line or "has IPv6 address" in line:
                    parts = line.split()
                    if parts:
                        return parts[-1]
        except Exception:
            pass
    return None

def probe_http(host: str, timeout: int = 5):
    res = {"http": False, "https": False, "http_header": "", "https_header": "", "http_sample": "", "https_sample": ""}
    for proto in ("http", "https"):
        url = f"{proto}://{host}"
        try:
            if requests:
                h = requests.head(url, timeout=timeout, allow_redirects=True)
                res[proto] = True if h.status_code else False
                res[f"{proto}_header"] = "\n".join(f"{k}: {v}" for k,v in h.headers.items())
                try:
                    g = requests.get(url, timeout=timeout, allow_redirects=True)
                    res[f"{proto}_sample"] = g.text[:2000]
                except Exception:
                    pass
            else:
                if check_command("curl"):
                    p = run_cmd(["curl", "-sS", "--max-time", str(timeout), "-I", url], timeout=timeout)
                    if p.returncode == 0 and p.stdout:
                        res[proto] = True
                        res[f"{proto}_header"] = p.stdout
                    p2 = run_cmd(["curl", "-sS", "--max-time", str(timeout), url], timeout=timeout)
                    if p2.returncode == 0 and p2.stdout:
                        res[f"{proto}_sample"] = p2.stdout[:2000]
        except Exception:
            pass
    return res

def fingerprint_host(host: str, out_root: Path):
    safe = host.replace('/', '_').replace(':', '_')
    host_dir = out_root / safe
    ensure_dir(host_dir)
    ip = resolve_host(host)
    host_dir.joinpath('info.txt').write_text(f"host: {host}\nip: {ip}\n")
    probe = probe_http(host)
    host_dir.joinpath('http_probe.txt').write_text(str(probe))
    if probe.get('http_header'):
        host_dir.joinpath('http_headers.txt').write_text(probe['http_header'])
    if probe.get('https_header'):
        host_dir.joinpath('https_headers.txt').write_text(probe['https_header'])
    if probe.get('http_sample'):
        host_dir.joinpath('http_sample.html').write_text(probe['http_sample'])
    if probe.get('https_sample'):
        host_dir.joinpath('https_sample.html').write_text(probe['https_sample'])
    return host

def main():
    import argparse
    parser = argparse.ArgumentParser(description='Automated Recon & Enumeration (lite)')
    parser.add_argument('target', help='Target name (used for outputs dir)')
    parser.add_argument('--use-sublist3r', action='store_true', help='Run Sublist3r (requires clone)')
    parser.add_argument('--sublist3r-path', default=default_sublist3r_path(), help='Path to sublist3r.py')
    parser.add_argument('--from-file', help='Use existing subdomains file instead of running Sublist3r')
    parser.add_argument('--workers', type=int, default=30, help='Concurrent workers (default 30)')
    args = parser.parse_args()

    out_root = Path('outputs') / args.target
    ensure_dir(out_root)
    raw_file = out_root / 'subdomains_raw.txt'

    if args.use_sublist3r:
        print('[*] Running Sublist3r...')
        run_sublist3r(args.target, args.sublist3r_path, raw_file)
    elif args.from_file:
        src = Path(args.from_file)
        if not src.exists():
            print('[!] input file not found:', src)
            sys.exit(1)
        shutil.copy2(src, raw_file)
    else:
        print('[!] Provide --use-sublist3r or --from-file')
        sys.exit(2)

    dedup_file = out_root / 'subdomains_unique.txt'
    dedupe_file(raw_file, dedup_file)

    resolved = []
    print('[*] Resolving hosts (concurrent)...')
    with ThreadPoolExecutor(max_workers=args.workers) as ex:
        futures = {ex.submit(resolve_host, ln.strip()): ln.strip() for ln in dedup_file.read_text().splitlines() if ln.strip()}
        for f in as_completed(futures):
            host = futures[f]
            try:
                ip = f.result()
                if ip:
                    resolved.append(host)
            except Exception:
                pass

    (out_root / 'resolved.txt').write_text('\n'.join(resolved) + ('\n' if resolved else ''))
    print(f'[+] Resolved {len(resolved)} hosts -> {out_root / "resolved.txt"}')

    fp_root = out_root / 'fingerprints'
    ensure_dir(fp_root)
    print('[*] Running HTTP probes (concurrent)...')
    with ThreadPoolExecutor(max_workers=args.workers) as ex:
        futures = [ex.submit(fingerprint_host, h, fp_root) for h in resolved]
        for f in as_completed(futures):
            try:
                h = f.result()
                print('[+] probed', h)
            except Exception as e:
                print('[!] probe error', e)

    print('[*] Done. See outputs in', out_root)

if __name__ == '__main__':
    main()
