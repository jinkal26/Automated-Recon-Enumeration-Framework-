#!/usr/bin/env bash
set -euo pipefail

echo "[*] Installing prerequisites on Kali Linux..."
sudo apt update
sudo apt install -y python3-pip git nmap curl dnsutils

# Optional fingerprinting tools
sudo apt install -y whatweb wafw00f nikto || true

echo "[*] Installing Python packages (requests)..."
pip3 install --user requests

echo "[*] Setup complete. Clone Sublist3r if you want to use it:"
echo "  git clone https://github.com/aboul3la/Sublist3r.git"
