#!/usr/bin/env bash
# Usage: ./resolve_subdomains.sh input_unique.txt output_resolved.txt
if [ $# -ne 2 ]; then
  echo "Usage: $0 input_unique.txt output_resolved.txt"
  exit 1
fi
INPUT=$1
OUTPUT=$2
> "$OUTPUT"
while read -r host; do
  [ -z "$host" ] && continue
  if host "$host" >/dev/null 2>&1; then
    echo "$host"
  fi
done < "$INPUT" > "$OUTPUT"
echo "[+] Wrote resolved hosts to $OUTPUT"
