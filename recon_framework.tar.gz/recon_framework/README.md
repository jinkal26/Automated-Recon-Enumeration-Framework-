# Recon Framework (Kali) - Lightweight Project

This project contains a lightweight, terminal-friendly recon tool for Kali Linux
that performs fast subdomain collection (via Sublist3r), deduplication,
DNS resolution, and HTTP/HTTPS liveness checks.

**Important:** Only run these tools against domains you own or have explicit permission to test.

## Contents

- `setup.sh` - install prerequisites on Kali (run with sudo).
- `recon_all_in_one_lite.py` - Fast Python tool (use Sublist3r or a file).
- `resolve_subdomains.sh` - Bash helper that filters only resolving hosts.
- `fingerprint_hosts.sh` - Optional fingerprinting script (nmap/whatweb/wafw00f/nikto).
- `examples/` - example usage commands.

## Quick start

1. Clone Sublist3r (if you will use it):
   ```bash
   git clone https://github.com/aboul3la/Sublist3r.git
   ```

2. Install prerequisites:
   ```bash
   sudo bash setup.sh
   ```

3. Run Sublist3r + fast processing:
   ```bash
   # using Sublist3r (default path ./Sublist3r/sublist3r.py)
   python3 recon_all_in_one_lite.py --use-sublist3r example.com

   # or using an existing file of subdomains:
   python3 recon_all_in_one_lite.py --from-file subs.txt example.com
   ```

Results are saved under `outputs/<target>/`:
- `subdomains_raw.txt`
- `subdomains_unique.txt`
- `resolved.txt`
- `fingerprints/` (if you run the optional fingerprinting script)
