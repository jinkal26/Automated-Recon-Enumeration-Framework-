#!/usr/bin/env bash
set -euo pipefail

echo "[*] Installing prerequisites (may ask for sudo password)..."
sudo apt update
sudo apt install -y python3-pip git nmap whatweb wafw00f nikto dnsutils curl

echo "[*] Installing Python package 'requests' for HTTP probing"
pip3 install --user requests

echo "[*] Done. If you plan to use Sublist3r, clone it into this folder or supply --sublist3r-path."
echo "    git clone https://github.com/aboul3la/Sublist3r.git"
