#!/usr/bin/env bash
# Quick fingerprinting wrapper that runs nmap -sV on resolved hosts list.
# Usage: ./fingerprint_hosts.sh resolved.txt
if [ $# -ne 1 ]; then
  echo "Usage: $0 resolved.txt"
  exit 1
fi
IN=$1
OUTDIR="fingerprints"
mkdir -p "$OUTDIR"
while read -r host; do
  [ -z "$host" ] && continue
  echo "[*] nmap -sV for $host"
  nmap -Pn -sV -p 80,443,8080,8443 "$host" -oA "$OUTDIR/$host" || true
done < "$IN"
echo "[+] Done. See $OUTDIR/"
